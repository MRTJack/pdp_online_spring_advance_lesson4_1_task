package uz.pdp.pdp_advance_p2p_project.p2p_program.exeption;

public class CardNotOwnedException extends RuntimeException {
public CardNotOwnedException(String message){
    super(message);
}
}
