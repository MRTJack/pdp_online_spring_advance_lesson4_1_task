package uz.pdp.pdp_advance_p2p_project.p2p_program.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.Income;

public interface IncomeRepository extends JpaRepository<Income, Long> {
}