package uz.pdp.pdp_advance_p2p_project.p2p_program.exeption;

public class CardNotActiveException extends RuntimeException {

    public CardNotActiveException(String message) {
        super(message);
    }

}