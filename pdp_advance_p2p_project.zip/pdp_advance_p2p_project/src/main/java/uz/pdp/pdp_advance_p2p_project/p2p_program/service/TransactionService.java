package uz.pdp.pdp_advance_p2p_project.p2p_program.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.Card;
import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.Income;
import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.Outcome;
import uz.pdp.pdp_advance_p2p_project.p2p_program.exeption.CardNotActiveException;
import uz.pdp.pdp_advance_p2p_project.p2p_program.exeption.CardNotFoundException;
import uz.pdp.pdp_advance_p2p_project.p2p_program.exeption.InsufficientFundsException;
import uz.pdp.pdp_advance_p2p_project.p2p_program.repo.CardRepository;
import uz.pdp.pdp_advance_p2p_project.p2p_program.repo.IncomeRepository;
import uz.pdp.pdp_advance_p2p_project.p2p_program.repo.OutcomeRepository;
import uz.pdp.pdp_advance_p2p_project.p2p_program.service.jwtService.JwtService;

@Service
public class TransactionService {

    @Autowired
    private CardRepository cardRepository;

    @Autowired
    private IncomeRepository incomeRepository;

    @Autowired
    private OutcomeRepository outcomeRepository;

    @SuppressWarnings("unused")
    @Autowired
    private JwtService jwtService;

    @Autowired
    private CardService cardService;

    @Transactional
    public void makeTransaction(String fromCardUsername, String toCardNumber, double amount, String jwtToken) {
        cardService.validateCardOwnership(fromCardUsername, jwtToken);

        Card fromCard = cardRepository.findByUsername(fromCardUsername)
                .orElseThrow(() -> new CardNotFoundException("Card not found"));

        Card toCard = cardRepository.findByNumber(toCardNumber)
                .orElseThrow(() -> new CardNotFoundException("Recipient card not found"));

        validateCardState(fromCard, toCard, amount);
        processTransaction(fromCard, toCard, amount);
        saveTransactionDetails(fromCard, toCard, amount);
    }

    private void validateCardState(Card fromCard, Card toCard, double amount) {
        if (!fromCard.isActive() || !toCard.isActive()) {
            throw new CardNotActiveException("One of the cards is not active");
        }

        if (fromCard.getBalance() < amount) {
            throw new InsufficientFundsException("Insufficient funds on the card");
        }
    }

    @SuppressWarnings("null")
    private void processTransaction(Card fromCard, Card toCard, double amount) {
        fromCard.setBalance(fromCard.getBalance() - amount);
        toCard.setBalance(toCard.getBalance() + amount);

        cardRepository.saveAll(List.of(fromCard, toCard));
    }

    @SuppressWarnings("null")
    private void saveTransactionDetails(Card fromCard, Card toCard, double amount) {
        List<Income> incomes = List.of(
                Income.builder().fromCard(fromCard).toCard(toCard).amount(amount).date(new Date()).build()
        );

        List<Outcome> outcomes = List.of(
                Outcome.builder().fromCard(fromCard).toCard(toCard).amount(amount).date(new Date())
                        .commissionAmount(calculateCommission(amount)).build()
        );

        incomeRepository.saveAll(incomes);
        outcomeRepository.saveAll(outcomes);
    }

    private double calculateCommission(double amount) {
        if (amount <= 1000) {
            return amount * 0.03;
        } else if (amount <= 5000) {
            return amount * 0.02;
        } else {
            return amount * 0.01;
        }
    }
}
