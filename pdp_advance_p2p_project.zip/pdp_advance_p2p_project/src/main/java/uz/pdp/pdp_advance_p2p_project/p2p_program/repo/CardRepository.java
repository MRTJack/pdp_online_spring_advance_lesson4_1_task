package uz.pdp.pdp_advance_p2p_project.p2p_program.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.Card;

public interface CardRepository extends JpaRepository<Card, Long> {
    Optional<Card> findByUsername(String username);
    Optional<Card> findByNumber(String number);
}