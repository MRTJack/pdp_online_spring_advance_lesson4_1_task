package uz.pdp.pdp_advance_p2p_project.p2p_program.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.Card;
import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.User;
import uz.pdp.pdp_advance_p2p_project.p2p_program.exeption.CardNotFoundException;
import uz.pdp.pdp_advance_p2p_project.p2p_program.exeption.CardNotOwnedException;
import uz.pdp.pdp_advance_p2p_project.p2p_program.repo.CardRepository;
import uz.pdp.pdp_advance_p2p_project.p2p_program.service.jwtService.JwtService;

@Service
public class CardService {

    @Autowired
    private JwtService jwtService;

    @Autowired
    private CardRepository cardRepository;

    @SuppressWarnings("unlikely-arg-type")
    public void validateCardOwnership(String cardUsername, String jwtToken) {
        User user = jwtService.getUserFromJwtToken(jwtToken);
        
        Card card = cardRepository.findByUsername(cardUsername)
                .orElseThrow(() -> new CardNotFoundException("Card not found"));

        if (!card.getUsername().equals(user)) {
            throw new CardNotOwnedException("Card does not belong to the user");
        }
    }
}

