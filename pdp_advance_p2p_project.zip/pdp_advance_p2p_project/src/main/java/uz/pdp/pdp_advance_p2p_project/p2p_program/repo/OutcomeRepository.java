package uz.pdp.pdp_advance_p2p_project.p2p_program.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.Outcome;

@Repository
public interface OutcomeRepository extends JpaRepository<Outcome,Long> {
    
}
