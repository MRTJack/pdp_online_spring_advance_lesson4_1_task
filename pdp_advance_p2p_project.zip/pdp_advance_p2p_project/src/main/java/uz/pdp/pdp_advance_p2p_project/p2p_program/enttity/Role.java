package uz.pdp.pdp_advance_p2p_project.p2p_program.enttity;

public enum Role {
    USER,
    ADMIN
}
