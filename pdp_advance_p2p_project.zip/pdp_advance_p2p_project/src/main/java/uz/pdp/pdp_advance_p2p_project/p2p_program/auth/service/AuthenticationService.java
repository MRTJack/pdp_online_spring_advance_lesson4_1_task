package uz.pdp.pdp_advance_p2p_project.p2p_program.auth.service;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import uz.pdp.pdp_advance_p2p_project.p2p_program.auth.request.AuthenticationRequest;
import uz.pdp.pdp_advance_p2p_project.p2p_program.auth.response.AuthenticationResponse;
import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.Role;
import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.User;
import uz.pdp.pdp_advance_p2p_project.p2p_program.register.RegisterRequest;
import uz.pdp.pdp_advance_p2p_project.p2p_program.repo.UserRepository;
import uz.pdp.pdp_advance_p2p_project.p2p_program.service.jwtService.JwtService;

import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authManager;

    @SuppressWarnings("null")
    public AuthenticationResponse register(RegisterRequest request) {
        User user = buildUserFromRequest(request);
        userRepository.save(user);
        String jwtToken = jwtService.generateToken(user);
        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }

    public AuthenticationResponse authenticate(AuthenticationRequest request) {
        try {
            authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                            request.getPassword()
                    )
            );
        } catch (AuthenticationCredentialsNotFoundException e) {
            throw new BadCredentialsException("Invalid email or password");
        }

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        String jwtToken = jwtService.generateToken(user);
        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }

    private User buildUserFromRequest(RegisterRequest request) {
        return User.builder()
        .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.USER)
                .build();
    }
}

