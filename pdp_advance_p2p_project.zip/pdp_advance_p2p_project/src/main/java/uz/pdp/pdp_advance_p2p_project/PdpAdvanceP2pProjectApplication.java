package uz.pdp.pdp_advance_p2p_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdpAdvanceP2pProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdpAdvanceP2pProjectApplication.class, args);
	}

}
