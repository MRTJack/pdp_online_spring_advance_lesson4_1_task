package uz.pdp.pdp_advance_p2p_project.p2p_program.service.jwtService;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import uz.pdp.pdp_advance_p2p_project.p2p_program.enttity.User;
import uz.pdp.pdp_advance_p2p_project.p2p_program.repo.UserRepository;

@Service
public class JwtService {
    private static final String SECRET_KEY = "sirli";

    @Autowired
    UserRepository userRepository;
/**
 * 
 * @param <T>
 * @param token
 * @param calimsResolver
 * Metod "extractClaim" token va funksional 
 * da'volarni qabul qiladi. JWT bo'yicha aniq 
 * utverjdeniya (da'vo) izvlecheniya uchun shu
 *  metodi qo'llaniladi.
 */
public <T> T extractClaim(String token, Function<Claims, T> calimsResolver){
    final Claims claims = extractAllClaims(token);
    return calimsResolver.apply(claims);
}


/**
 * "ExtractUsername" usuli tokendan 
 * izvlecheniya imeni polzovatelya (mavzu)
 *  uchun da'vo ko'chirmani ishlatadi.
 * @param token
 * @return
 */
    public String extractUsername(String token) {
        return extractClaim(token,Claims::getSubject);
    }


    /**
     * "ExtractAllClaims" xususiy usuli Jwts kutubxonasi
     *  yordamida JWT-larni tahlil qiladi
     *  va Claims obyektini qaytaradi.
     * @param token
     * @return
     */
    private Claims extractAllClaims(String token){
        return Jwts
        .parserBuilder()
        .setSigningKey(getSignInKey())
        .build()
        .parseClaimsJws(token)
        .getBody();
    }



    /**
     * Xususiy getSignInKey usuli token autentifikatsiyasi
     *  uchun imzo kalitini qaytaradi.
     *  Sizning holatingizda kalit SECRET_KEY asosida yaratilgan.
     * @return
     */
    private java.security.Key getSignInKey() {
        byte[] keyBytes=Decoders.BASE64.decode(SECRET_KEY);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * GenereToken usuli taqdim etilgan da'volar (extraClaims)
     *  va foydalanuvchi ma'lumotlari (userDetails)
     *  asosida yangi token yaratadi. Token shaxsiy kalit yordamida imzolanadi.
     * @param exctraClaims
     * @param userDetails
     * @return
     */
    public String generateToken(
        Map<String, Object> exctraClaims,
        UserDetails userDetails
    ){
        return Jwts
        .builder()
        .setClaims(exctraClaims)
        .setSubject(userDetails.getUsername())
        .setIssuedAt(new Date(System.currentTimeMillis()))
        .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 24))
        .signWith(getSignInKey(), SignatureAlgorithm.HS256)
        .compact();


    }


    /**
     * Qo'shimcha tasdiqlarsiz generatorTokenning
     *  haddan tashqari yuklangan versiyasi.
     *  U faqat foydalanuvchi ma'lumotlari
     *  asosida token yaratish uchun ishlatiladi.
     * @param userDetails
     * @return
     */
    public String generateToken(UserDetails userDetails){
        return generateToken(new HashMap<>(),userDetails);
    }

    /**
     * isTokenValid usuli o'tkazilgan token belgilangan
     *  foydalanuvchi uchun to'g'ri yoki yo'qligini tekshiradi.
     *  U tokendagi foydalanuvchi nomini UserDetails foydalanuvchi
     *  nomi bilan solishtiradi va token muddati tugaganligini tekshiradi.
     * @param token
     * @param userDetails
     * @return
     */
    public boolean isTokenValid(String token, UserDetails userDetails){
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername())) && !isTokenExpired(token);
    }

    /**
     * Xususiy isTokenExpired
     *  usuli tokenning amal qilish muddati tugaganligini tekshiradi.
     * @param token
     * @return
     */
    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    /**
     * Maxfiy ekstraktiExpiration usuli tokenning amal
     *  qilish muddatini uning tasdiqlaridan ajratib oladi.
     * @param token
     * @return
     */
    private Date extractExpiration(String token) {
        return extractClaim(token,Claims::getExpiration);
    }

    public User getUserFromJwtToken(String jwtToken) {
        if (jwtToken == null || jwtToken.isEmpty()) {
            throw new JwtException("Invalid or empty JWT token provided");
        }

        try {
            @SuppressWarnings("deprecation")
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(SECRET_KEY)
                    .build()
                    .parseClaimsJws(jwtToken)
                    .getBody();

            Long userId = claims.get("userId", Long.class);

            User user = userRepository.findUserById(userId);

            if (user == null) {
                throw new UsernameNotFoundException("User with ID " + userId + " not found");
            }

            return user;

        } catch (ExpiredJwtException e) {
            throw new JwtException("JWT token expired");
        } catch (JwtException e) {
            throw new JwtException("Error processing JWT token: " + e.getMessage());
        }
    }
}
