package uz.pdp.pdp_advance_p2p_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdpAdvanceP2pProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
